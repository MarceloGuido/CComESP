namespace Final 
{
    using MySql.Data.MySqlClient;
    using System.Net.WebSockets;
    using static System.Net.Mime.MediaTypeNames;
    using System.Windows.Forms;
    using MySqlX.XDevAPI;
    using Org.BouncyCastle.Utilities;
    using static System.Windows.Forms.VisualStyles.VisualStyleElement;
    using System.Text.Unicode;
    using System.Text;
    using System;
    using System.Data;
    using System.Windows.Forms.VisualStyles;

    public partial class Form1 : Form
    {
        //Respons�vel pela conex�o com banco de dados
        public static MySqlConnection conexao;

        //Respons�vel pelas instru��es � serem executadas
        public static MySqlCommand comando;

        //Respons�vel por inserir dados em uma DataTable
        public static MySqlDataAdapter adaptador;

        //Responsavel por ligar o Banco e controles com a propriedade DataSource
        public static DataTable dataTabela;

        ClientWebSocket webSocket;
        public Form1()
        {
            InitializeComponent();
        }

/*        private void Form1_Load(object sender, EventArgs e)
        {
            conexao = new MySqlConnection("server=localhost;database=db_iot;uid=root;pwd=\\\"\\\";\") // server=localhost; uid=root; pwd=;");
        }
*/
        private void btnBd_Click(object sender, EventArgs e)
        {
            //            string connetionString = null;
            //            MySqlConnection cnn;
            //            connetionString = "server=localhost;database=db_iot;uid=root;pwd=\"\";";
            //            cnn = new MySqlConnection(connetionString);
            /*            try
                        {
                            conexao.Open();
                            MessageBox.Show("Conex�o Aberta! ");
                            conexao.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("N�o foi poss�vel abrir a conex�o! ");
                        }

                           {

                               //Abre a conex�o com o BD
                               conexao.Open();

                               //Informa a instru��o/comando SQL
                               comando = new MySqlCommand("CREATE DATABASE IF NOT EXISTS db_iot; use db_iot; ", conexao);

                               //Executa a instru��o no MySQL 
                               comando.ExecuteNonQuery();

                               //Informa outra instru��o/comando SQL
                               comando = new MySqlCommand("CREATE TABLE IF NOT EXISTS tbl_dc( " +
                                                                       "id INTEGER AUTO_INCREMENT PRIMARY KEY, " +
                                                                       "data VARCHAR(12), " +
                                                                       "hora Varchar(6), " +
                                                                       "temp Varchar(4), " +
                                                                       "umidade VARCHAR(4)); ", conexao);
                               comando.ExecuteNonQuery();
                               conexao.Clone();

                           }
                        */
            // Dados da conex�o
            string servidor = "localhost";
            string usuario = "root"; // usu�rio padr�o do XAMPP
            string senha = ""; // senha padr�o do XAMPP (deixe vazio se n�o houver)
            string banco = "db_iot"; // nome do banco de dados

            // String de conex�o
            string conexaoString = $"Server={servidor};Database={banco};Uid={usuario};Pwd={senha};";

            try
            {
                using (MySqlConnection conexao = new MySqlConnection(conexaoString))
                {
                    conexao.Open();
                    MessageBox.Show("Conex�o estabelecida com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao conectar: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

private async Task ReceiveMessages() // M�todo ass�ncrono para receber mensagens do WebSocket
        {
            var buffer = new byte[1024]; // Cria um buffer de bytes para armazenar os dados recebidos
            while (webSocket.State == WebSocketState.Open) // Loop enquanto a conex�o WebSocket estiver aberta
            {
                try
                {
                    var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None); // Recebe uma mensagem do WebSocket de forma ass�ncrona
                    var message = Encoding.UTF8.GetString(buffer, 0, result.Count); // Converte os bytes recebidos em uma string usando UTF-8

                    // Atualiza o TextBox apropriado com a mensagem recebida
                    textBox1.Invoke((MethodInvoker)(() => UpdateTextBox(message))); // Chama o m�todo para atualizar o TextBox correspondente
                }
                catch (Exception ex) // Bloco de captura para exce��es (erros)
                {
                    labelStatus.Invoke((MethodInvoker)(() => labelStatus.Text = "Desconectado")); // Atualiza o lblStatus para mostrar "Desconectado" na UI
                    MessageBox.Show("Erro ao receber mensagem: " + ex.Message); // Exibe uma mensagem de erro ao usu�rio
                }
            }
        }
        //Vai ser necess�rio criar um protocolo para o envio das mensagens//////
        // M�todo para atualizar o TextBox baseado na mensagem recebida
        private async void UpdateTextBox(string message)
        {
            switch (message.Substring(0, 4))
            {
                case "data":
                    textBox1.Invoke((MethodInvoker)(() => textBoxData.AppendText($"{message.Substring(4)}\n\r"))); // Atualiza textBoxRecebidas na UI para mostrar a mensagem recebida
                    break;
                case "hora":
                    textBox1.Invoke((MethodInvoker)(() => textBoxHora.AppendText($"{message.Substring(4)}\n\r"))); // Atualiza textBoxRecebidas na UI para mostrar a mensagem recebida
                    break;
                case "temp":
                    textBox1.Invoke((MethodInvoker)(() => textBoxTemp.AppendText($"{message.Substring(4)}\n\r"))); // Atualiza textBoxRecebidas na UI para mostrar a mensagem recebida
                    break;
                case "umid":
                    textBox1.Invoke((MethodInvoker)(() => textBoxUmi.AppendText($"{message.Substring(4)}\n\r"))); // Atualiza textBoxRecebidas na UI para mostrar a mensagem recebida
                    break;
                default:
                    break;
            }
        }

        private async void btnEsp_Click(object sender, EventArgs e)
        {
            webSocket = new ClientWebSocket(); // Inicializa uma nova inst�ncia de ClientWebSocket
            Uri serverUri = new Uri("ws://192.168.0.117:8080"); // Define o URI do servidor WebSocket, substitua pelo IP do seu ESP32
            try
            {
                await webSocket.ConnectAsync(serverUri, CancellationToken.None); //Tenta conectar ao servidor WebSocket de forma ass�ncrona
                labelStatus.Invoke((MethodInvoker)(() => labelStatus.Text = "Conectado")); // Atualiza o lblStatus para mostrar "Conectado" na UI
                await ReceiveMessages(); // Chama o m�todo para receber mensagens do servidor WebSocket
            }
            catch (Exception ex) // Bloco de captura para exce��es
            {
                labelStatus.Invoke((MethodInvoker)(() => labelStatus.Text = "Desconectado")); // Atualiza o lblStatus para mostrar "Desconectado" na UI
                MessageBox.Show("Erro ao conectar: " + ex.Message); // Exibe uma mensagem de erro ao usu�rio
            }
        }

        private async void btnColetar_Click(object sender, EventArgs e)
        {
            textBoxData.Text = "";
            textBoxHora.Text = "";
            textBoxTemp.Text = "";
            textBoxUmi.Text = "";

            var message = "on"; // Define a mensagem "on"
            var bytes = Encoding.UTF8.GetBytes(message); // Converte a mensagem em um array de bytes usando UTF - 8
            await webSocket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None); // Envia a mensagem via WebSocket de forma ass�ncrona
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*
            if (conexao.State == ConnectionState.Closed)
            {
                conexao.Open();
            }
            comando = new MySqlCommand("INSERT INTO tbl_dc (data, hora, temp, umidade) " +
                                               "VALUES('" + textBoxData.Text + "', '" + textBoxHora.Text + "', '" +
                                                textBoxTemp.Text + "', '" + textBoxUmi.Text + "');", conexao);
            int deuCerto = comando.ExecuteNonQuery();
            if (deuCerto > 0)
            {
                MessageBox.Show("Dados inseridos");
            }
            //Fecha a conex�o com o Banco de Dados
            conexao.Close();

        }*/
            // Dados a serem salvos
            string data = textBoxData.Text;
            string hora = textBoxHora.Text;
            string temperatura = textBoxTemp.Text; // Exemplo de temperatura
            string umidade = textBoxUmi.Text; // Exemplo de umidade

            // Dados da conex�o
            string servidor = "localhost";
            string usuario = "root"; // usu�rio padr�o do XAMPP
            string senha = ""; // senha padr�o do XAMPP (deixe vazio se n�o houver)
            string banco = "db_iot"; // nome do banco de dados

            // String de conex�o
            string conexaoString = $"Server={servidor};Database={banco};Uid={usuario};Pwd={senha};";

            // Consulta SQL para inserir dados
            string query = "INSERT INTO tbl_dc (data, hora, temp, umidade) VALUES (@data, @hora, @temperatura, @umidade)";

            try
            {
                using (MySqlConnection conexao = new MySqlConnection(conexaoString))
                {
                    conexao.Open();

                    using (MySqlCommand comando = new MySqlCommand(query, conexao))
                    {
                        // Adiciona par�metros
                        comando.Parameters.AddWithValue("@data", data);
                        comando.Parameters.AddWithValue("@hora", hora);
                        comando.Parameters.AddWithValue("@temperatura", temperatura);
                        comando.Parameters.AddWithValue("@umidade", umidade);

                        // Executa a consulta
                        int linhasAfetadas = comando.ExecuteNonQuery();
                        MessageBox.Show($"{linhasAfetadas} registro(s) salvo(s) com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao salvar os dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
