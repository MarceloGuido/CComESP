﻿namespace Final
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEsp = new Button();
            btnBd = new Button();
            labelStatus = new Label();
            btnColetar = new Button();
            label1 = new Label();
            label2 = new Label();
            textBoxTemp = new TextBox();
            textBoxUmi = new TextBox();
            label3 = new Label();
            label4 = new Label();
            textBox1 = new TextBox();
            textBoxHora = new TextBox();
            textBoxData = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // btnEsp
            // 
            btnEsp.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEsp.Location = new Point(57, 31);
            btnEsp.Name = "btnEsp";
            btnEsp.Size = new Size(209, 72);
            btnEsp.TabIndex = 0;
            btnEsp.Text = "Conectar ao ESP";
            btnEsp.UseVisualStyleBackColor = true;
            btnEsp.Click += btnEsp_Click;
            // 
            // btnBd
            // 
            btnBd.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBd.Location = new Point(579, 31);
            btnBd.Name = "btnBd";
            btnBd.Size = new Size(209, 72);
            btnBd.TabIndex = 1;
            btnBd.Text = "Testar conexão com o BD";
            btnBd.UseVisualStyleBackColor = true;
            btnBd.Click += btnBd_Click;
            // 
            // labelStatus
            // 
            labelStatus.AutoSize = true;
            labelStatus.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelStatus.Location = new Point(292, 54);
            labelStatus.Name = "labelStatus";
            labelStatus.Size = new Size(136, 28);
            labelStatus.TabIndex = 3;
            labelStatus.Text = "Desconectado";
            // 
            // btnColetar
            // 
            btnColetar.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnColetar.Location = new Point(61, 157);
            btnColetar.Name = "btnColetar";
            btnColetar.Size = new Size(727, 49);
            btnColetar.TabIndex = 4;
            btnColetar.Text = "Coletar dados do ESP";
            btnColetar.UseVisualStyleBackColor = true;
            btnColetar.Click += btnColetar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(404, 221);
            label1.Name = "label1";
            label1.Size = new Size(132, 28);
            label1.TabIndex = 5;
            label1.Text = "Temperatura";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(579, 221);
            label2.Name = "label2";
            label2.Size = new Size(96, 28);
            label2.TabIndex = 6;
            label2.Text = "Umidade";
            label2.Click += label2_Click;
            // 
            // textBoxTemp
            // 
            textBoxTemp.Location = new Point(404, 265);
            textBoxTemp.Name = "textBoxTemp";
            textBoxTemp.Size = new Size(154, 27);
            textBoxTemp.TabIndex = 7;
            // 
            // textBoxUmi
            // 
            textBoxUmi.Location = new Point(579, 265);
            textBoxUmi.Name = "textBoxUmi";
            textBoxUmi.Size = new Size(154, 27);
            textBoxUmi.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(61, 221);
            label3.Name = "label3";
            label3.Size = new Size(57, 28);
            label3.TabIndex = 9;
            label3.Text = "Data";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(235, 221);
            label4.Name = "label4";
            label4.Size = new Size(58, 28);
            label4.TabIndex = 10;
            label4.Text = "Hora";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(57, 387);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(314, 27);
            textBox1.TabIndex = 11;
            // 
            // textBoxHora
            // 
            textBoxHora.Location = new Point(235, 265);
            textBoxHora.Name = "textBoxHora";
            textBoxHora.Size = new Size(154, 27);
            textBoxHora.TabIndex = 12;
            // 
            // textBoxData
            // 
            textBoxData.Location = new Point(61, 265);
            textBoxData.Name = "textBoxData";
            textBoxData.Size = new Size(154, 27);
            textBoxData.TabIndex = 13;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(57, 312);
            button1.Name = "button1";
            button1.Size = new Size(731, 52);
            button1.TabIndex = 14;
            button1.Text = "Enviar dados acima para o BD";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(textBoxData);
            Controls.Add(textBoxHora);
            Controls.Add(textBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(textBoxUmi);
            Controls.Add(textBoxTemp);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnColetar);
            Controls.Add(labelStatus);
            Controls.Add(btnBd);
            Controls.Add(btnEsp);
            Name = "Form1";
            Text = "Atividade Final";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEsp;
        private Button btnBd;
        private Label labelStatus;
        private Button btnColetar;
        private Label label1;
        private Label label2;
        private TextBox textBoxTemp;
        private TextBox textBoxUmi;
        private Label label3;
        private Label label4;
        private TextBox textBox1;
        private TextBox textBoxHora;
        private TextBox textBoxData;
        private Button button1;
    }
}
